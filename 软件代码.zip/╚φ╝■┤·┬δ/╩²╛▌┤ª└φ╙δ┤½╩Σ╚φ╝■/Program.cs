﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestLoraPort.ServiceReference1; //导入webService

namespace TestLoraPort
{
    struct B_RSSI {
        public int f_number;
        public double rssi;
    }
    class Program
    {
        static UsePort Link;
        static double[,,] data = new double[20,5,3];//创建三轴循环队列数组
        static int[] Axis_Index = new int[20];//创建不同设备的三轴循环队列索引数组
        //static double[,] Rssi_data = new double[20,5];//创建不同设备获取的信标RSSI的循环队列数组
        static int[] Rssi_index = new int[20];//创建RSSI循环队列索引数组
        static B_RSSI[,] rssi_f_number = new B_RSSI[20,5];//创建不同设备获取的信标RSSI的循环队列数组
        static int[] F_Number = new int[20];//用于存储对应设备号所在楼层号
        static void Main(string[] args)
        {
            //定义批次变量并初始化
            int maxBatchCode = 0;
            //初始化索引数组
            for (int i = 0; i < 20; i++)
            {
                Axis_Index[i] = 0;
            }
            //初始化Axis队列数组
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        data[i, j, k] = 0;
                    }
                }
            }
            //初始化RSSI循环队列索引数组
            for (int i = 0;i < 20;i++)
            {
                Rssi_index[i] = 0;
            }
            //初始化信标RSSI结构体队列数组
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    rssi_f_number[i, j].f_number = 0;
                    rssi_f_number[i, j].rssi = 0;
                }
                
            }
            //初始化楼层数组
            for (int i = 0;i < 20;i++)
            {
                F_Number[i] = 0;
            }
            TestservicePortClient service = new TestservicePortClient();//创建webService实例
            try
            {
                maxBatchCode = Convert.ToInt32(service.getBatchCodeMax());//获取数据批次的最大值
                maxBatchCode++;                                           //批次加一
                String[] data1 = new String[15];
                String[] data2 = new String[15];
                Link = new UsePort();
                while (true)
                {
                    Link.DataReceived();
                    data1 = Link.getXY_String().Split('\n');
                    for (int i = 0; i < data1.Length; i++)
                    {
                        data2 = data1[i].Split(',');
                        if (data2.Length >= 2)
                        {
                            try
                            {
                                if (data2[1].Equals("0"))
                                {
                                    int id = int.Parse(data2[0]);
                                    double x = double.Parse(data2[4]);
                                    double y = double.Parse(data2[5]);
                                    double z = double.Parse(data2[6]);
                                    //Console.WriteLine("三轴X：{0},三轴Y：{1},三轴Z：{2},ID:{3}",x, y, z,id);
                                    updateAxisQueue(id, x, y, z);
                                    Console.WriteLine("三轴X：{0},三轴Y：{1},三轴Z：{2},ID:{3},状态:{4},index:{5}", x, y, z, id,getStatus(id),Axis_Index[id]);
                                    //data2[3] = (((Int32)Convert.ToDouble(data2[3]) - 100290) / 5).ToString();
                                    if (service.addRealMonitoringDataUpdateOrInsert(maxBatchCode.ToString(), data2[0], id.ToString(), data2[2], getStatus(id), "1", data2[4], data2[5], "1", "1", get_nearest_number(id).ToString(), data2[3], "0", "0", "0").Equals("1"))
                                    {
                                        if (!service.addRealMonitoringData(maxBatchCode.ToString(), data2[0], id.ToString(), data2[2], getStatus(id), "1", data2[4], data2[5], "1", "1", get_nearest_number(id).ToString(), data2[3], "0", "0", "0").Equals("1"))//将定位点发送回服务器
                                        {
                                        }
                                    }
                                    //Console.WriteLine("温度：{0},气压：{1},三轴X：{2},三轴Y：{3},三轴Z：{4},L_RSSI:{5}", data2[2], data2[3], data2[4], data2[5], data2[6], data2[7]);
                                }
                                else if (data2[1].Equals("1"))
                                {
                                    int id = int.Parse(data2[0]);
                                    get_floor_number(id,data2[2]);
                                    updateRssiQueue(int.Parse(data2[0]),double.Parse(data2[3]),F_Number[id]);
                                    Console.WriteLine("B_MAC：{0},楼层：{1},ID:{2}", data2[2], get_nearest_number(id),id);
                                    //Console.WriteLine("楼层：{0}",get_nearest_number(int.Parse(data2[0])));
                                }
                            }
                            catch (Exception)
                            {
                                continue;
                            }
                        }
                    }

                    Link.Reset();
                    Thread.Sleep(500);
                }
           }
           catch (Exception)
           {
                //Console.WriteLine("未连接网络{0}", floor_number);
                Console.WriteLine("未连接网络{0},10秒后退出", maxBatchCode);
               Thread.Sleep(10000);
            }
        }
        /// <summary>
        /// 用于通过蓝牙来判断所在楼层位置
        /// </summary>
        /// <param name="B_MAC">蓝牙mac地址</param>
        /// <param name="B_RSSI">蓝牙信号强度</param>
        /// <returns>返回所在楼层数</returns>
        static void get_floor_number(int id,String B_MAC)
        {
            //int j = 0;
            //String[] RSSI = new String[15];
            String[] B = { "dc:47:7f:8c:5e:f5", "ef:49:65:02:d9:37", "c0:b1:1e:26:ef:07", "07:fe:a0:40:e0:d2", "05:40:40:7e:ae:0c", "31:45:6e:09:9d:5c", "d2:f5:79:37:3f:ce", "00:ec:10:09:bc:02", "01:6d:78:1d:91:ee", " 07:0d:3c:18:9a:fb", "7c:cf:08:35:3b:01", "fc:85:54:e2:fa:82", "07:4a:00:4e:19:46", "02:db:f8:3b:3b:3d", "03:1b:18:29:0a:20", "04:a1:d8:6f:87:7e", "e8:c5:4d:26:0a:33", "01:41:08:1e:30:e0", "03:b7:60:26:bb:ef", "2b:7d:6f:78:9e:b4" };//填入蓝牙MAC地址，对应的下标即为相应楼层
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 //for (int i =0;i < 15;i++) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 // RSSI[i] = "999";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 // }
            for (int i = 0; i < B.Length; i++)
            {
                if (B[i].Equals(B_MAC))
                {
                    F_Number[id] = i;
                }
            }
        }
        /// <summary>
        /// 用于检测到多个蓝牙信号时，判断哪个蓝牙距离最近的方法
        /// </summary>
        /// <param name="id">设备号</param>
        /// <returns>返回距离最近的蓝牙所在楼层数</returns>
        static int get_nearest_number(int id)
        {
            int temp = rssi_f_number[id, Rssi_index[id]].f_number;
            double min = rssi_f_number[id, Rssi_index[id]].rssi;
            if (Rssi_index[id] >= 2)
            {  
                if (min > rssi_f_number[id, Rssi_index[id] - 1].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id] - 1].rssi;
                    temp = rssi_f_number[id, Rssi_index[id] - 1].f_number;
                }
                if (min > rssi_f_number[id, Rssi_index[id] - 2].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id] - 2].rssi;
                    temp = rssi_f_number[id, Rssi_index[id] - 2].f_number;
                }

            }
            else if (Rssi_index[id] == 1)
            {
                if (min > rssi_f_number[id, Rssi_index[id] - 1].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id] - 1].rssi;
                    temp = rssi_f_number[id, Rssi_index[id] - 1].f_number;
                }
                if (min > rssi_f_number[id, Rssi_index[id]+3].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id]+3].rssi;
                    temp = rssi_f_number[id, Rssi_index[id]+3].f_number;
                }
            }
            else if (Rssi_index[id] == 0)
            {
                if (min > rssi_f_number[id, Rssi_index[id]+4].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id]+4].rssi;
                    temp = rssi_f_number[id, Rssi_index[id]+4].f_number;
                }
                if (min > rssi_f_number[id, Rssi_index[id] + 3].rssi)
                {
                    min = rssi_f_number[id, Rssi_index[id] + 3].rssi;
                    temp = rssi_f_number[id, Rssi_index[id] + 3].f_number;
                }
            }
            return temp;
        }
        ///<summary>
        ///用于检测运动姿态
        ///</summary>
        ///<param name="id">设备号</param>
        static String getStatus(int id)
        {
            //if (id == 2)
            //{
                if (Axis_Index[id] >= 2)
                {
                    //锯齿波形判断
                    double D_value1 = data[id, Axis_Index[id], 1] - data[id, Axis_Index[id] - 1, 1];
                    double D_calue2 = data[id, Axis_Index[id] - 1, 1] - data[id, Axis_Index[id] - 2, 1];
                    if (D_value1*D_calue2 < 0 && (Math.Abs(D_value1) > 5 || Math.Abs(D_calue2) > 5) )
                    {
                        return "正在移动";
                    }
                    else
                    {
                        return "未移动";
                    }
                }
                else if (Axis_Index[id] == 1)
                {
                    //锯齿波形判断
                    double D_value1 = data[id, Axis_Index[id], 1] - data[id, Axis_Index[id] - 1, 1];
                    double D_calue2 = data[id, Axis_Index[id] - 1, 1] - data[id, Axis_Index[id] + 3, 1];
                    if (D_value1 * D_calue2 < 0 && (Math.Abs(D_value1) > 5 || Math.Abs(D_calue2) > 5))
                    {
                        return "正在移动";
                    }
                    else
                    {
                        return "未移动";
                    }
                }
                else if (Axis_Index[id] == 0)
                {
                    //锯齿波形判断
                    double D_value1 = data[id, Axis_Index[id], 1] - data[id, Axis_Index[id] + 4, 1];
                    double D_calue2 = data[id, Axis_Index[id] + 4, 1] - data[id, Axis_Index[id] + 3, 1];
                    if (D_value1 * D_calue2 < 0 && (Math.Abs(D_value1) > 5 || Math.Abs(D_calue2) > 5))
                    {
                        return "正在移动";
                    }
                    else
                    {
                        return "未移动";
                    }
                }
                else
                {
                    return "计算中";
                }
            //}
            //else
            //{
               // return "未移动";
           // }
        }
        ///<summary>
        ///更新三轴循环队列数据
        ///</summary>
        ///<param name="id">设备编号</param>
        ///<param name="x">三轴X方向加速度值</param>
        ///<param name="y">三轴Y方向加速度值</param>
        ///<param name="z">三轴Z方向加速度值</param>
        static void updateAxisQueue(int id,double x,double y,double z)
        {
            data[id,Axis_Index[id],0] = x;
            data[id,Axis_Index[id],1] = y;
            data[id,Axis_Index[id],2] = z;
            Axis_Index[id] = (Axis_Index[id] + 1) % 5;
        }
        ///<summary>
        ///更新RSSI循环队列数据
        ///</summary>
        ///<param name="f_number">设备判断的信标的楼层号</param>
        ///<param name="id">设备号</param>
        ///<param name="rssi">对应楼层的信标信号强度值</param>
        static void updateRssiQueue(int id,double rssi,int f_number)
        {
            rssi_f_number[id, Rssi_index[id]].rssi = Math.Abs(rssi);
            rssi_f_number[id, Rssi_index[id]].f_number = f_number;
            //Console.WriteLine("ID：{0},B_RSSI：{1},f_number：{2},index:{3}", id, rssi_f_number[id, Rssi_index[id]].rssi, rssi_f_number[id, Rssi_index[id]].f_number,Rssi_index[id]);
            Rssi_index[id] = (Rssi_index[id] + 1) % 5;
        }
    }
}
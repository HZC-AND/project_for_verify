1.数据处理与传输软件：用于接收处理以及传输网关数据的软件
	执行文件位置：定位测试软件->bin->Debug->TestLoraPort.exe
         
2.定位测试软件：用于测试硬件定位功能
	执行文件位置：数据处理与传输软件->bin->Debug->WindowsFormsApplication2.exe

PS：用户手册中有说明
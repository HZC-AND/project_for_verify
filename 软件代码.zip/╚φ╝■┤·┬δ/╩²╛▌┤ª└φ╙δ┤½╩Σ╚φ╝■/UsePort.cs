﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLoraPort
{
    public class UsePort
    {
        private SerialPort sp = null;//声明一个串口类
        private bool isOpen = false;//打开串口标志位
        private bool isSetProperty = false;//属性设置标志位
        private String portName;
        String XYString;
        public UsePort()//构造方法
        {
            Init();//初始化        
        }

        private void Init()//初始化方法
        {
            CheckCOM();//检测可用端口
           OpenCom();//打开端口并设置串口属性
            //OpenCom();//二次调用是关闭
        }
        private void CheckCOM()
        {
            bool comExistence = false;//有可用串口标志位
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    SerialPort sp = new SerialPort("COM" + (i + 1).ToString());
                    sp.Open();
                    sp.Close();
                    portName = "COM" + (i + 1).ToString();
                    comExistence = true;
                }
                catch (Exception)
                {
                    continue;
                }
            }
            if (comExistence)
            {
            }
            else
            {

            }
        }
        private void SetPortProperty()//设置串口属性
        {
            sp = new SerialPort();
            sp.PortName = portName.Trim();//设置端口名
            //sp.PortName = "COM7".Trim();
            sp.BaudRate = Convert.ToInt32("9600");//设置波特率
            sp.StopBits = StopBits.One;//设置停止位为0
            sp.DataBits = Convert.ToInt16("8");//设置数据位为8
            sp.Parity = Parity.None;//设置奇偶校验为无
            sp.ReadTimeout = -1;//设置超时读取时间

        }
        private void OpenCom()
        {
            if (isOpen == false)
            {
                if (!isSetProperty)//串口未设置则设置串口
                {
                    SetPortProperty();
                    isSetProperty = true;
                }
                try//打开串口
                {
                    sp.Open();
                    isOpen = true;
                }
                catch (Exception)
                {
                    //打开串口失败后，相应标志位取消
                    isSetProperty = false;
                    isOpen = false;

                }
            }
            else
            {
                try//打开串口
                {
                    sp.Close();
                    isOpen = false;
                    isSetProperty = false;
                }
                catch (Exception)
                {

                }
            }
        }
        public void DataReceived()//数据接收
        {
            System.Threading.Thread.Sleep(100);//延迟100ms等待接收完数据


            Byte[] ReceivedDate = new Byte[sp.BytesToRead];//创建接收字节数组
            //XYString = sp.ReadLine();
            //XYString = System.Text.Encoding.Default.GetString(ReceivedDate);
            if (ReceivedDate.Length > 0)
            {
            sp.Read(ReceivedDate, 0, ReceivedDate.Length);//读取所接收到的数据
            XYString = Encoding.ASCII.GetString(ReceivedDate);
            //for (int i = 0;i < ReceivedDate.Length;i++)
            //{
            //XYString += ReceivedDate[0].ToString();
            //} 

            sp.DiscardInBuffer();//丢弃接收缓冲区数据
            }

        }
        public void DataSend(String Data)//数据发送
        {
            if (isOpen)//写串口数据
            {
                try
                {
                    sp.WriteLine(Data);
                }
                catch (Exception)
                {

                    return;
                }
            }
            else
            {

                return;
            }
            if (Data.Equals(""))//检测要发送的数据
            {

                return;
            }
        }
        public String getXY_String()
        {
            if (XYString != null)
            {
                return XYString;
            }
            else
                return "error";
        }
        //重置变量
        public void Reset()
        {
            XYString = null;
        }
    }
}
